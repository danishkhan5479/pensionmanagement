package com.terra.pojos;

public class PackageDeliveryOutput {
	float packageDeliveryCharge;

	public float getPackageDeliveryCharge() {
		return packageDeliveryCharge;
	}

	public void setPackageDeliveryCharge(float packageDeliveryCharge) {
		this.packageDeliveryCharge = packageDeliveryCharge;
	}
}
