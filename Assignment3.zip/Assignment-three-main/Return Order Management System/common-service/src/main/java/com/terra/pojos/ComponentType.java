package com.terra.pojos;

public enum ComponentType {
	INTEGRAL, ACCESSORY, PROTECTIVE_SHEATH
}
